#include<iostream>
using namespace std;
int main(){
cout<<"Muhammad Haider Ali";
return 0;
}

